import React from 'react';

const LoadingIcon = () => (
  <div id="loading-pokeball-container">
    <div id="loading-pokeball"></div>
  </div>
);

export default LoadingIcon;
